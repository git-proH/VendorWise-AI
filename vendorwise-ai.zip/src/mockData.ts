import { Vendor, Recommendation, Employee, Invoice, DashboardStats } from './types';
import { addDays, subDays, format } from 'date-fns';

export const MOCK_COMPANY_NAME = "NovaTech Solutions";

export const MOCK_VENDORS: Vendor[] = [
  {
    id: '1',
    name: 'Slack',
    category: 'Communication',
    totalSpend: 12400,
    monthlySpend: 1200,
    status: 'underutilized',
    lastBilled: format(subDays(new Date(), 5), 'yyyy-MM-dd'),
    renewalDate: format(addDays(new Date(), 25), 'yyyy-MM-dd'),
    utilizationScore: 65,
    seatCount: 150,
    activeUsers: 92,
  },
  {
    id: '2',
    name: 'Zoom',
    category: 'Video Conferencing',
    totalSpend: 8200,
    monthlySpend: 650,
    status: 'inactive',
    lastBilled: format(subDays(new Date(), 12), 'yyyy-MM-dd'),
    renewalDate: format(addDays(new Date(), 5), 'yyyy-MM-dd'),
    utilizationScore: 28,
    seatCount: 80,
    activeUsers: 23,
  },
  {
    id: '3',
    name: 'AWS',
    category: 'Infrastructure',
    totalSpend: 45000,
    monthlySpend: 4200,
    status: 'active',
    lastBilled: format(subDays(new Date(), 2), 'yyyy-MM-dd'),
    renewalDate: format(addDays(new Date(), 28), 'yyyy-MM-dd'),
    utilizationScore: 94,
    seatCount: 1,
    activeUsers: 1,
  },
  {
    id: '4',
    name: 'Canva',
    category: 'Design',
    totalSpend: 3200,
    monthlySpend: 280,
    status: 'underutilized',
    lastBilled: format(subDays(new Date(), 15), 'yyyy-MM-dd'),
    renewalDate: format(addDays(new Date(), 45), 'yyyy-MM-dd'),
    utilizationScore: 12,
    seatCount: 20,
    activeUsers: 2,
  },
  {
    id: '5',
    name: 'HubSpot',
    category: 'CRM',
    totalSpend: 15000,
    monthlySpend: 1200,
    status: 'active',
    lastBilled: format(subDays(new Date(), 10), 'yyyy-MM-dd'),
    renewalDate: format(addDays(new Date(), 20), 'yyyy-MM-dd'),
    utilizationScore: 82,
    seatCount: 15,
    activeUsers: 12,
  },
  {
    id: '6',
    name: 'Discord',
    category: 'Communication',
    totalSpend: 500,
    monthlySpend: 50,
    status: 'inactive',
    lastBilled: format(subDays(new Date(), 20), 'yyyy-MM-dd'),
    renewalDate: format(addDays(new Date(), 10), 'yyyy-MM-dd'),
    utilizationScore: 0,
    seatCount: 10,
    activeUsers: 0,
  }
];

export const MOCK_RECOMMENDATIONS: Recommendation[] = [
  {
    id: 'r1',
    vendorId: '2',
    vendorName: 'Zoom',
    title: 'Downgrade to Pro Plan',
    description: 'You have 80 Enterprise seats but only 23 active users in the last 30 days. Downgrade to save on license fees.',
    projectedSavings: 1200,
    impact: 'high',
    type: 'downgrade',
    status: 'pending',
  },
  {
    id: 'r2',
    vendorId: '4',
    vendorName: 'Canva',
    title: 'Remove Inactive Seats',
    description: '18 out of 20 seats have been inactive for over 60 days. Removing these can save $240/month.',
    projectedSavings: 2880,
    impact: 'medium',
    type: 'downgrade',
    status: 'pending',
  },
  {
    id: 'r3',
    vendorId: '6',
    vendorName: 'Discord',
    title: 'Cancel Overlapping Tool',
    description: 'Discord is being paid for but has zero active users. Slack is the primary communication tool.',
    projectedSavings: 600,
    impact: 'low',
    type: 'cancel',
    status: 'pending',
  }
];

export const MOCK_INVOICES: Invoice[] = [
  { id: 'inv1', vendorName: 'AWS', amount: 4230.45, date: '2024-05-01', status: 'paid' },
  { id: 'inv2', vendorName: 'Slack', amount: 1200.00, date: '2024-05-05', status: 'paid' },
  { id: 'inv3', vendorName: 'Zoom', amount: 650.00, date: '2024-05-08', status: 'flagged' },
];

export const MOCK_STATS: DashboardStats = {
  totalMonthlySpend: 7580,
  estimatedWaste: 2450,
  optimizationScore: 68,
  upcomingRenewals: 3,
  vendorRiskScore: 42,
};
