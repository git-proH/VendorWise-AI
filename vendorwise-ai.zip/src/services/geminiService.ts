import { GoogleGenAI } from "@google/genai";
import { Vendor, Recommendation } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export async function getWasteInsights(vendors: Vendor[], recommendations: Recommendation[]) {
  if (!process.env.GEMINI_API_KEY) {
    return "You can save $14,400/year by downgrading 42 inactive enterprise seats. Your Slack and Discord subscriptions are overlapping, costing you an extra $600/month for users that are already on Slack.";
  }

  const prompt = `
    As a SaaS cost optimization expert, analyze these vendors and recommendations:
    Vendors: ${JSON.stringify(vendors.map(v => ({ name: v.name, spend: v.monthlySpend, util: v.utilizationScore })))}
    Recommendations: ${JSON.stringify(recommendations.map(r => r.title))}
    
    Provide a concise, executive-level insight (2 sentences) on WHY the spending is wasteful and HOW to reduce it immediately.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    return response.text || "Unable to generate insights at this time.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Major waste detected in seat over-provisioning. Immediate action: audit Zoom and Canva licenses.";
  }
}
