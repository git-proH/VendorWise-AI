/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import AppLayout from './components/layout/AppLayout';
import Dashboard from './components/dashboard/Dashboard';
import LandingPage from './components/layout/LandingPage';
import AIScanner from './components/scanner/AIScanner';
import { useAppStore } from './store';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { auth, googleProvider, signInWithPopup, signOut } from './lib/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';

// Views
const VendorsView = () => {
  const { vendors } = useAppStore();
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold">Vendor Directory</h1>
          <p className="text-sm text-neutral-400">Total active subscriptions tracked via automated monitoring.</p>
        </div>
      </div>
      <Card className="border-white/5 bg-neutral-900/40 backdrop-blur-sm">
        <CardContent className="p-0">
          <Table>
            <TableHeader className="border-white/5 hover:bg-transparent">
              <TableRow className="border-white/5 hover:bg-transparent text-xs text-neutral-500 uppercase tracking-wider">
                <TableHead className="font-medium">Vendor</TableHead>
                <TableHead className="font-medium">Category</TableHead>
                <TableHead className="font-medium">Status</TableHead>
                <TableHead className="font-medium">Monthly Spend</TableHead>
                <TableHead className="font-medium">Utilization</TableHead>
                <TableHead className="font-medium">Renewal</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {vendors.map((vendor) => (
                <TableRow key={vendor.id} className="border-white/5 hover:bg-white/5 transition-colors cursor-pointer">
                  <TableCell className="font-medium py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded bg-neutral-800 flex items-center justify-center font-bold text-xs uppercase">
                        {vendor.name[0]}
                      </div>
                      {vendor.name}
                    </div>
                  </TableCell>
                  <TableCell className="text-neutral-400 text-xs">{vendor.category}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className={
                      vendor.status === 'active' ? "bg-brand-success/10 text-brand-success border-brand-success/20" :
                      vendor.status === 'underutilized' ? "bg-brand-warning/10 text-brand-warning border-brand-warning/20" :
                      "bg-brand-danger/10 text-brand-danger border-brand-danger/20"
                    }>
                      {vendor.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-mono text-sm">${vendor.monthlySpend}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div className="w-24 h-1 bg-white/5 rounded-full overflow-hidden">
                        <div 
                          className={vendor.utilizationScore > 80 ? "bg-brand-success h-full" : vendor.utilizationScore > 40 ? "bg-brand-warning h-full" : "bg-brand-danger h-full"} 
                          style={{ width: `${vendor.utilizationScore}%` }}
                        />
                      </div>
                      <span className="text-[10px] text-neutral-500">{vendor.utilizationScore}%</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-neutral-400 text-xs">{vendor.renewalDate}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

const WasteView = () => {
  const { recommendations } = useAppStore();
  return (
    <div className="space-y-6">
       <div className="bg-brand-danger/5 border border-brand-danger/20 p-8 rounded-3xl glow-red relative overflow-hidden">
        <div className="relative z-10">
          <h2 className="text-3xl font-bold text-brand-danger">Waste Analysis Report</h2>
          <p className="text-neutral-400 mt-2 max-w-xl">Our Waste Detection Engine has analyzed your stack and found $2,450 in leaking capital per month.</p>
        </div>
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <Trash2 className="w-32 h-32 text-brand-danger" />
        </div>
      </div>
      <AIScanner />
    </div>
  );
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('dashboard');
  const { isDemoMode, setDemoMode } = useAppStore();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Login failed:", error);
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  if (loading) {
    return (
      <div className="h-screen w-screen bg-neutral-950 flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-brand-accent border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <LandingPage onGetStarted={handleLogin} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'vendors':
        return <VendorsView />;
      case 'waste':
        return <WasteView />;
      case 'invoices':
        return <AIScanner />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <AppLayout activeTab={activeTab} setActiveTab={setActiveTab}>
      {renderContent()}
      
      {/* Demo Mode Toggle Overlay */}
      <div className="fixed bottom-6 right-6 flex items-center gap-2">
        <button 
          onClick={handleLogout}
          className="px-4 py-2 bg-white/10 backdrop-blur-md text-white text-xs font-bold rounded-full border border-white/10 hover:bg-white/20 transition-all"
        >
          Logout
        </button>
        <button 
          onClick={() => setDemoMode(!isDemoMode)}
          className="px-4 py-2 bg-brand-accent text-white text-xs font-bold rounded-full shadow-2xl hover:scale-105 transition-all glow-blue"
        >
          {isDemoMode ? "Live Environment: NovaTech Solutions" : "Load Demo Dashboard"}
        </button>
      </div>
    </AppLayout>
  );
}

function Trash2(props: any) {
  return (
    <svg 
      {...props} 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    >
      <path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/>
    </svg>
  );
}

