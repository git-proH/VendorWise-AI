/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type SubscriptionStatus = 'active' | 'inactive' | 'underutilized';

export interface Vendor {
  id: string;
  name: string;
  icon?: string;
  category: string;
  totalSpend: number;
  monthlySpend: number;
  status: SubscriptionStatus;
  lastBilled: string;
  renewalDate: string;
  utilizationScore: number; // 0-100
  seatCount: number;
  activeUsers: number;
}

export interface Recommendation {
  id: string;
  vendorId: string;
  vendorName: string;
  title: string;
  description: string;
  projectedSavings: number;
  impact: 'low' | 'medium' | 'high';
  type: 'cancel' | 'downgrade' | 'merge' | 'negotiate';
  status: 'pending' | 'applied' | 'dismissed';
}

export interface Employee {
  id: string;
  name: string;
  email: string;
  department: string;
  activeTools: string[]; // vendor IDs
  lastActive: string;
  status: 'active' | 'inactive';
}

export interface DashboardStats {
  totalMonthlySpend: number;
  estimatedWaste: number;
  optimizationScore: number;
  upcomingRenewals: number;
  vendorRiskScore: number;
}

export interface Invoice {
  id: string;
  vendorName: string;
  amount: number;
  date: string;
  status: 'paid' | 'pending' | 'flagged';
  items?: string[];
}
