import React from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowUpRight, 
  ArrowDownRight, 
  DollarSign, 
  AlertCircle, 
  Zap, 
  ShieldCheck,
  TrendingUp,
  Clock
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';
import { useAppStore } from '../../store';

const data = [
  { month: 'Jan', spend: 4200, waste: 800 },
  { month: 'Feb', spend: 3800, waste: 600 },
  { month: 'Mar', spend: 5200, waste: 1200 },
  { month: 'Apr', spend: 4800, waste: 900 },
  { month: 'May', spend: 5800, waste: 1400 },
  { month: 'Jun', spend: 7580, waste: 2450 },
];

const vendorData = [
  { name: 'AWS', spend: 4200, color: '#3b82f6' },
  { name: 'Slack', spend: 1200, color: '#a855f7' },
  { name: 'HubSpot', spend: 1200, color: '#f97316' },
  { name: 'Zoom', spend: 650, color: '#0ea5e9' },
  { name: 'Other', spend: 330, color: '#64748b' },
];

export default function Dashboard() {
  const { stats, vendors, recommendations } = useAppStore();

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { y: 20, opacity: 0 },
    show: { y: 0, opacity: 1 }
  };

  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-8"
    >
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Executive Summary</h1>
          <p className="text-neutral-400 mt-1">Real-time health overview of your company's vendor ecosystem.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right hidden md:block">
            <p className="text-xs text-neutral-500 font-medium uppercase tracking-wider">Active Monitoring</p>
            <p className="text-sm font-semibold">23 Tools Integrated</p>
          </div>
          <Button variant="outline" className="border-white/10 bg-white/5 hover:bg-white/10">
            <Clock className="w-4 h-4 mr-2" />
            Last Sync: 12m ago
          </Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="Monthly SaaS Spend" 
          value={`$${stats.totalMonthlySpend.toLocaleString()}`}
          change="+2.4%"
          trend="up"
          icon={DollarSign}
        />
        <StatCard 
          title="Estimated Annual Waste" 
          value={`$${(stats.estimatedWaste * 12).toLocaleString()}`}
          change="Potential 18% reduction"
          trend="down"
          icon={AlertCircle}
          variant="danger"
        />
        <StatCard 
          title="Active Subscriptions" 
          value="84"
          change="3 pending renewals"
          trend="neutral"
          icon={Zap}
        />
        <StatCard 
          title="Financial Health Score" 
          value={`${stats.optimizationScore}`}
          subValue="/100"
          change="+8 pts"
          trend="up"
          icon={ShieldCheck}
          variant="success"
          progress={stats.optimizationScore}
        />
      </div>

      <div className="grid grid-cols-12 gap-6">
        {/* Main Chart area for Insights */}
        <Card className="col-span-12 lg:col-span-8 border-zinc-800 bg-zinc-900 rounded-xl overflow-hidden shadow-sm h-fit">
          <CardHeader className="p-5 border-b border-zinc-800 flex flex-row justify-between items-center space-y-0">
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <span className="px-1.5 py-0.5 bg-indigo-500/10 text-indigo-400 rounded text-xs font-bold">AI</span>
              Strategic Recommendations
            </CardTitle>
            <span className="text-xs text-zinc-500">Real-time analysis active</span>
          </CardHeader>
          <CardContent className="p-5 space-y-4">
            {recommendations.slice(0, 3).map((rec, idx) => (
              <div key={rec.id} className="flex gap-4">
                <div className={cn(
                  "w-8 h-8 rounded-full flex-shrink-0 flex items-center justify-center",
                  idx % 2 === 0 ? "bg-indigo-600 shadow-lg shadow-indigo-600/20" : "bg-zinc-700"
                )}>
                  {idx % 2 === 0 ? <Zap className="w-4 h-4 text-white" /> : <AlertCircle className="w-4 h-4" />}
                </div>
                <div className="bg-zinc-800/40 rounded-2xl p-4 text-sm leading-relaxed border border-zinc-800 flex-1 group hover:border-zinc-700 transition-colors">
                  <div className="flex justify-between items-start mb-2">
                    <p className="font-medium text-zinc-100">{rec.title}</p>
                    <span className="text-emerald-400 font-bold">Save ${rec.projectedSavings}</span>
                  </div>
                  <p className="text-zinc-400 mb-4">{rec.description}</p>
                  <div className="flex gap-2">
                    <Button size="sm" className="h-7 text-[10px] bg-emerald-500 hover:bg-emerald-600 text-emerald-950 font-bold border-none">Approve Change</Button>
                    <Button size="sm" variant="outline" className="h-7 text-[10px] border-zinc-700 text-zinc-300 bg-transparent hover:bg-zinc-700">View Audit Trail</Button>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Highest Spend Vectors */}
        <Card className="col-span-12 lg:col-span-4 border-zinc-800 bg-zinc-900 rounded-xl overflow-hidden shadow-sm">
          <CardHeader className="p-5 border-b border-zinc-800">
            <CardTitle className="text-base font-medium">Highest Spend Vectors</CardTitle>
          </CardHeader>
          <CardContent className="p-5 space-y-6">
            {vendorData.map((vendor, idx) => (
              <div key={vendor.name} className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-zinc-400">{vendor.name}</span>
                  <span className="font-medium font-mono">${vendor.spend.toLocaleString()}</span>
                </div>
                <div className="w-full bg-zinc-800 h-2 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${(vendor.spend / 4200) * 100}%` }}
                    className="bg-indigo-500 h-full rounded-full"
                  />
                </div>
              </div>
            ))}
            
            <div className="pt-4 border-t border-zinc-800">
              <div className="bg-rose-500/10 p-4 rounded-lg border border-rose-500/20">
                <div className="text-rose-400 text-xs font-bold uppercase tracking-tighter mb-1">Alert: Renewal at Risk</div>
                <div className="text-sm text-zinc-200"><strong>Zendesk Enterprise</strong> renewal in 48 hours. Auto-renew enabled. Estimated waste: 22%.</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Grid for Bottom Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 border-zinc-800 bg-zinc-900 rounded-xl overflow-hidden shadow-sm">
          <CardHeader className="p-5 border-b border-zinc-800">
            <CardTitle className="text-base font-medium">Spend Analysis Trend</CardTitle>
          </CardHeader>
          <CardContent className="h-[280px] p-5">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorSpend" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#ffffff05" />
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: '#52525b', fontSize: 11 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#52525b', fontSize: 11 }} tickFormatter={(val) => `$${val}`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a', borderRadius: '8px', fontSize: '12px' }}
                  itemStyle={{ color: '#fff' }}
                />
                <Area type="monotone" dataKey="spend" stroke="#4f46e5" fillOpacity={1} fill="url(#colorSpend)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Top Vendors Status */}
        <Card className="border-zinc-800 bg-zinc-900 rounded-xl overflow-hidden shadow-sm">
          <CardHeader className="p-5 border-b border-zinc-800">
            <CardTitle className="text-base font-medium">Vendor Health Check</CardTitle>
          </CardHeader>
          <CardContent className="p-5 space-y-4">
            {vendors.slice(0, 4).map((vendor) => (
              <div key={vendor.id} className="group">
                <div className="flex justify-between items-center mb-1.5">
                  <span className="text-sm font-medium">{vendor.name}</span>
                  <Badge variant="outline" className={cn(
                    "text-[10px] px-1.5 py-0 border-none",
                    vendor.utilizationScore > 80 ? "bg-emerald-500/10 text-emerald-400" :
                    vendor.utilizationScore > 40 ? "bg-amber-500/10 text-amber-400" : "bg-rose-500/10 text-rose-400"
                  )}>
                    {vendor.utilizationScore}% usage
                  </Badge>
                </div>
                <div className="w-full bg-zinc-800 h-1 rounded-full overflow-hidden">
                  <div 
                    className={cn(
                      "h-full rounded-full transition-all duration-1000",
                      vendor.utilizationScore > 80 ? "bg-emerald-400" :
                      vendor.utilizationScore > 40 ? "bg-amber-400" : "bg-rose-400"
                    )}
                    style={{ width: `${vendor.utilizationScore}%` }}
                  />
                </div>
              </div>
            ))}
            <Button variant="ghost" className="w-full text-xs text-zinc-500 hover:text-zinc-300 pt-4">Generate Compliance Report</Button>
          </CardContent>
        </Card>
      </div>
    </motion.div>
  );
}

function StatCard({ title, value, subValue, change, trend, icon: Icon, variant = 'primary', progress }) {
  const textColors = {
    primary: 'text-zinc-100',
    success: 'text-emerald-400',
    danger: 'text-rose-500',
    warning: 'text-amber-500',
  };

  return (
    <Card className="border-zinc-800 bg-zinc-900 p-5 rounded-xl shadow-sm group hover:border-zinc-700 transition-all duration-300">
      <div className="flex flex-col h-full">
        <div className="text-zinc-500 text-sm mb-1">{title}</div>
        <div className="flex items-baseline gap-1">
          <div className={cn("text-2xl font-semibold tracking-tight", textColors[variant])}>{value}</div>
          {subValue && <span className="text-zinc-500 text-sm">{subValue}</span>}
        </div>
        
        {progress !== undefined ? (
          <div className="w-full bg-zinc-800 h-1 rounded-full mt-3 overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              className="bg-emerald-400 h-full" 
            />
          </div>
        ) : null}

        <div className={cn(
          "text-xs mt-2 flex items-center gap-1 font-medium",
          variant === 'danger' ? "text-rose-400" : 
          variant === 'success' ? "text-emerald-400" :
          trend === 'up' ? "text-emerald-400" : 
          trend === 'down' ? "text-rose-400" : "text-zinc-500"
        )}>
          {trend === 'up' && <ArrowUpRight className="w-3.5 h-3.5" />}
          {change}
        </div>
      </div>
    </Card>
  );
}
