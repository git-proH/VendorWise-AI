import React from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle, Calendar, Clock, BellRing, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAppStore } from '../../store';
import { format, differenceInDays, parseISO } from 'date-fns';
import { cn } from '@/lib/utils';

export default function RenewalCenter() {
  const { vendors } = useAppStore();
  
  const upcomingRenewals = vendors
    .map(v => ({
      ...v,
      daysToRenewal: differenceInDays(parseISO(v.renewalDate), new Date())
    }))
    .filter(v => v.daysToRenewal < 30)
    .sort((a, b) => a.daysToRenewal - b.daysToRenewal);

  return (
    <Card className="border-zinc-800 bg-zinc-900 rounded-xl overflow-hidden shadow-sm">
      <CardHeader className="p-5 border-b border-zinc-800">
        <div>
          <CardTitle className="text-base font-medium flex items-center gap-2">
            <BellRing className="w-5 h-5 text-amber-500" />
            Renewal Risk Center
          </CardTitle>
          <CardDescription className="text-zinc-500 text-xs mt-1">Track upcoming contracts and auto-renewal deadlines</CardDescription>
        </div>
      </CardHeader>
      <CardContent className="p-5 space-y-4">
        {upcomingRenewals.map((vendor) => (
          <div 
            key={vendor.id} 
            className="group flex items-center justify-between p-4 rounded-xl border border-zinc-800 bg-zinc-950/30 hover:bg-zinc-800/50 transition-all cursor-pointer"
          >
            <div className="flex items-center gap-4">
              <div className={cn(
                "w-12 h-12 rounded-lg flex items-center justify-center font-bold text-lg",
                vendor.daysToRenewal < 7 ? "bg-rose-500/10 text-rose-500 border border-rose-500/20" : "bg-zinc-800 text-zinc-500 border border-zinc-700"
              )}>
                {vendor.name[0]}
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-sm">{vendor.name}</h4>
                  {vendor.daysToRenewal < 7 && (
                    <Badge className="bg-rose-500 text-white border-none text-[8px] h-3 px-1 uppercase font-black">CRITICAL</Badge>
                  )}
                </div>
                <div className="flex items-center gap-3 text-[10px] text-zinc-500 font-bold uppercase tracking-widest">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {vendor.renewalDate}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {vendor.daysToRenewal} Days Left
                  </span>
                </div>
              </div>
            </div>
            
            <div className="text-right">
              <p className="text-xs font-bold mb-1.5 text-zinc-100">${vendor.monthlySpend.toLocaleString()}/mo</p>
              <Button size="sm" variant="outline" className="h-6 text-[9px] border-zinc-700 text-zinc-400 bg-transparent hover:bg-zinc-700 hover:text-white transition-all uppercase font-bold tracking-widest px-2">
                Audit Plan <ArrowRight className="ml-1 w-2.5 h-2.5" />
              </Button>
            </div>
          </div>
        ))}

        <div className="pt-6 mt-2 border-t border-zinc-800">
          <div className="flex items-center justify-between text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em] px-1">
            <span>Overall Risk Score</span>
            <span className="text-amber-500">Medium Risk</span>
          </div>
          <div className="mt-3 h-1.5 bg-zinc-800 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: '42%' }}
              className="h-full bg-amber-500"
            />
          </div>
          <p className="mt-4 text-[10px] text-zinc-500 leading-relaxed italic border-l border-zinc-800 pl-3">
            "Pro-tip: Slack and Zoom renewals are both within 30 days. Consider negotiating a volume discount for your 150+ user base."
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
