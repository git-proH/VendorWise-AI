import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, FileText, CheckCircle2, AlertCircle, Scan, Sparkles, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useAppStore } from '../../store';
import { Badge } from '@/components/ui/badge';

export default function AIScanner() {
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<any>(null);
  const { addInvoice } = useAppStore();

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setIsScanning(true);
    setScanResult(null);
    
    // Simulate AI Scan
    setTimeout(() => {
      const result = {
        vendor: 'DataDog',
        amount: 842.50,
        date: '2024-05-15',
        confidence: 0.98,
        insights: 'Unexpected price increase of 12% detected compared to last month license count.',
        duplicate: false
      };
      setScanResult(result);
      setIsScanning(false);
      
      addInvoice({
        id: Math.random().toString(36).substr(2, 9),
        vendorName: result.vendor,
        amount: result.amount,
        date: result.date,
        status: 'flagged'
      });
    }, 3000);
  };

  return (
    <Card className="border-zinc-800 border-dashed border-2 bg-zinc-900/30 rounded-2xl overflow-hidden">
      <CardContent className="p-10">
        <div className="flex flex-col items-center justify-center text-center space-y-8">
          <div className="w-16 h-16 bg-indigo-600/10 rounded-2xl flex items-center justify-center glow-indigo border border-indigo-600/20">
            <Scan className="w-8 h-8 text-indigo-400" />
          </div>
          
          <div className="space-y-3">
            <h2 className="text-3xl font-bold tracking-tight text-white">AI Expense Scanner</h2>
            <p className="text-zinc-500 max-w-sm mx-auto text-sm font-medium leading-relaxed">
              Upload your SaaS invoices, screenshots, or PDF exports. Our AI will extract vendor data and check for waste.
            </p>
          </div>

          {!isScanning && !scanResult && (
            <div className="w-full max-w-sm">
              <label className="group block w-full p-10 border border-dashed border-zinc-800 rounded-3xl cursor-pointer hover:border-indigo-600/50 hover:bg-indigo-600/5 transition-all duration-500 shadow-inner">
                <input type="file" className="hidden" onChange={handleFileUpload} accept=".pdf,.png,.jpg,.csv" />
                <div className="flex flex-col items-center gap-4">
                  <Upload className="w-8 h-8 text-zinc-600 group-hover:text-indigo-400 transition-all duration-500" />
                  <span className="text-sm font-bold text-zinc-400 group-hover:text-white transition-colors uppercase tracking-widest">Drop files here to upload</span>
                  <span className="text-[10px] text-zinc-600 uppercase tracking-[0.2em] font-bold">PDF, PNG, JPG, CSV</span>
                </div>
              </label>
            </div>
          )}

          {isScanning && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex flex-col items-center gap-6 py-10"
            >
              <div className="relative">
                <Loader2 className="w-14 h-14 text-indigo-500 animate-spin" />
                <motion.div 
                  initial={{ top: '0%' }}
                  animate={{ top: '100%' }}
                  transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
                  className="absolute left-0 right-0 h-0.5 bg-indigo-400 shadow-[0_0_15px_rgba(129,140,248,0.5)]"
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center gap-2 justify-center">
                  <Sparkles className="w-4 h-4 text-indigo-400 animate-pulse" />
                  <p className="text-sm font-bold uppercase tracking-widest text-zinc-200">Gemini AI is parsing...</p>
                </div>
                <p className="text-xs text-zinc-500 font-medium">Extracting vendor names, line items, and seat counts</p>
              </div>
            </motion.div>
          )}

          <AnimatePresence>
            {scanResult && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="w-full max-w-md space-y-4 pt-6 text-left"
              >
                <div className="bg-zinc-950/50 border border-zinc-800 rounded-3xl p-8 space-y-6 shadow-2xl relative overflow-hidden group">
                  <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  
                  <div className="flex justify-between items-start relative z-10">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-zinc-800 border border-zinc-700 rounded-xl flex items-center justify-center font-bold text-xl text-white">D</div>
                      <div>
                        <h4 className="font-bold text-lg text-white">{scanResult.vendor}</h4>
                        <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">Subscription • Monthly</p>
                      </div>
                    </div>
                    <Badge className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full px-3 py-1 font-bold text-[10px] uppercase tracking-widest">
                      {Math.round(scanResult.confidence * 100)}% Match
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 relative z-10">
                    <div className="bg-zinc-900 p-4 rounded-2xl border border-zinc-800 shadow-inner">
                      <p className="text-[10px] text-zinc-500 uppercase font-bold tracking-widest mb-1">Amount</p>
                      <p className="text-2xl font-bold text-white tracking-tighter">${scanResult.amount}</p>
                    </div>
                    <div className="bg-zinc-900 p-4 rounded-2xl border border-zinc-800 shadow-inner group/stat">
                      <p className="text-[10px] text-zinc-500 uppercase font-bold tracking-widest mb-1">Anomalies</p>
                      <p className="text-sm font-bold text-rose-500">+12% vs Prev</p>
                    </div>
                  </div>

                  <div className="flex gap-4 p-4 bg-indigo-500/5 border border-indigo-500/10 rounded-2xl relative z-10">
                    <Sparkles className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
                    <p className="text-xs text-zinc-300 leading-relaxed italic font-medium">
                      "{scanResult.insights}"
                    </p>
                  </div>

                  <div className="flex gap-3 relative z-10 pt-2">
                    <Button onClick={() => setScanResult(null)} className="flex-1 h-12 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold uppercase tracking-widest text-[10px] shadow-lg shadow-indigo-600/20 border-none transition-all">
                      Accept & Log
                    </Button>
                    <Button onClick={() => setScanResult(null)} variant="outline" className="flex-1 h-12 rounded-xl border-zinc-800 text-zinc-500 hover:bg-zinc-800 hover:text-white font-bold uppercase tracking-widest text-[10px] transition-all">
                      Cancel
                    </Button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </CardContent>
    </Card>
  );
}
