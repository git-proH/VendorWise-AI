import React from 'react';
import { motion } from 'framer-motion';
import { 
  LayoutDashboard, 
  Receipt, 
  Trash2, 
  Users, 
  Settings, 
  Bell, 
  Search,
  CreditCard,
  Zap,
  TrendingDown
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function AppLayout({ children, activeTab, setActiveTab }: LayoutProps) {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'vendors', label: 'Vendor Inventory', icon: CreditCard },
    { id: 'waste', label: 'Waste Analysis', icon: Trash2 },
    { id: 'invoices', label: 'SaaS Spending', icon: Receipt },
    { id: 'usage', label: 'Usage', icon: Users },
  ];

  return (
    <div className="flex h-screen bg-zinc-950 text-zinc-100 font-sans overflow-hidden relative">
      {/* Background Mesh Effect */}
      <div className="absolute inset-0 pointer-events-none opacity-40">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-indigo-600/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-[20%] right-[-5%] w-[30%] h-[30%] bg-emerald-500/5 rounded-full blur-[100px]" />
      </div>

      {/* Sidebar */}
      <motion.aside 
        initial={{ x: -20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        className="w-64 border-r border-zinc-900 flex flex-col bg-zinc-950/80 backdrop-blur-3xl z-20"
      >
        <div className="p-8 flex items-center gap-2">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center glow-indigo border border-indigo-500/20">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-lg tracking-tight uppercase">VendorWise</span>
        </div>

        <nav className="flex-1 px-4 py-6 space-y-1">
          <div className="px-4 mb-4 text-[10px] font-bold text-zinc-600 uppercase tracking-[0.2em]">Management</div>
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold uppercase tracking-widest transition-all duration-300 border border-transparent group",
                activeTab === item.id 
                  ? "bg-zinc-900 text-white border-zinc-800 shadow-xl shadow-black/20" 
                  : "text-zinc-500 hover:text-zinc-200 hover:bg-zinc-900/50"
              )}
            >
              <item.icon className={cn("w-4 h-4 transition-colors duration-300", activeTab === item.id ? "text-indigo-400" : "text-zinc-600 group-hover:text-zinc-400")} />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="p-6 border-t border-zinc-900">
          <div className="bg-zinc-900/50 rounded-2xl p-4 border border-zinc-800">
            <div className="text-[9px] text-zinc-600 uppercase tracking-[0.2em] mb-3 font-bold">Enterprise Plan</div>
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-indigo-600/10 text-indigo-400 rounded-lg flex items-center justify-center text-xs font-black border border-indigo-600/10">
                NT
              </div>
              <div className="flex flex-col min-w-0">
                <span className="text-xs font-bold truncate text-zinc-200">NovaTech</span>
                <span className="text-[10px] text-zinc-500 truncate font-medium">Organization</span>
              </div>
            </div>
          </div>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative overflow-hidden z-10">
        {/* Header */}
        <header className="h-20 border-b border-zinc-900 flex items-center justify-between px-10 bg-zinc-950/50 backdrop-blur-xl z-20">
          <div className="flex items-center gap-6 flex-1">
            <div className="relative w-full max-w-md group">
              <Search className="absolute left-4 top-3 w-4 h-4 text-zinc-600 group-focus-within:text-indigo-400 transition-colors" />
              <input 
                type="text"
                placeholder="Search vendors, insights..."
                className="w-full bg-zinc-900/50 border border-zinc-800 rounded-2xl py-2.5 pl-12 pr-4 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-indigo-500/50 placeholder:text-zinc-600 transition-all focus:bg-zinc-900"
              />
            </div>
          </div>
          <div className="flex items-center gap-6">
            <Button size="sm" className="hidden sm:flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-6 h-11 rounded-full font-bold uppercase tracking-widest text-[10px] border-none shadow-xl shadow-indigo-600/10 transition-all hover:scale-102 active:scale-98">
              <Zap className="w-3.5 h-3.5" />
              Upload Invoices
            </Button>
            <Separator orientation="vertical" className="h-6 bg-zinc-800" />
            <button className="relative text-zinc-500 hover:text-white transition-all p-2 bg-zinc-900/50 border border-zinc-800 rounded-xl hover:bg-zinc-800">
              <Bell className="w-5 h-5" />
              <span className="absolute top-2.5 right-2.5 w-1.5 h-1.5 bg-rose-500 rounded-full border border-zinc-950" />
            </button>
            <div className="w-10 h-10 rounded-2xl bg-zinc-900 border border-zinc-800 p-0.5 cursor-pointer hover:border-zinc-700 transition-all">
              <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Felix" alt="avatar" className="w-full h-full rounded-[0.85rem]" />
            </div>
          </div>
        </header>

        {/* Scrollable Area */}
        <div className="flex-1 overflow-y-auto p-10 custom-scrollbar scroll-smooth">
          <div className="max-w-7xl mx-auto w-full">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}
