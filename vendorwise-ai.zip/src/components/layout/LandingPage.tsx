import React from 'react';
import { motion } from 'framer-motion';
import { 
  Zap, 
  ShieldCheck, 
  TrendingDown, 
  ArrowRight, 
  CheckCircle,
  BarChart3,
  Bot,
  Layers,
  MousePointer2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { DollarSign } from 'lucide-react';

export default function LandingPage({ onGetStarted }: { onGetStarted: () => void }) {
  return (
    <div className="min-h-screen bg-zinc-950 text-white selection:bg-indigo-600 selection:text-white overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-8 py-6 backdrop-blur-md bg-zinc-950/20 border-b border-zinc-900">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center glow-indigo">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-lg tracking-tight uppercase">VendorWise AI</span>
        </div>
        <div className="hidden md:flex items-center gap-8 text-xs font-bold uppercase tracking-widest text-zinc-500">
          <a href="#features" className="hover:text-white transition-colors">Features</a>
          <a href="#roi" className="hover:text-white transition-colors">ROI Calculator</a>
          <a href="#pricing" className="hover:text-white transition-colors">Pricing</a>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="ghost" className="text-zinc-500 hover:text-white text-xs font-bold uppercase tracking-widest">Login</Button>
          <Button onClick={onGetStarted} className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-full px-6 h-10 text-xs font-bold uppercase tracking-widest border-none shadow-lg shadow-indigo-600/20 transition-all">
            Get Started
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-48 pb-20 px-8">
        <div className="max-w-6xl mx-auto flex flex-col items-center text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-[10px] font-bold uppercase tracking-[0.2em] mb-12"
          >
            <Sparkles className="w-3 h-3" />
            Empowering 200+ Finance Teams
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-7xl md:text-9xl font-bold tracking-tighter leading-[0.85] mb-12 bg-clip-text text-transparent bg-gradient-to-b from-white to-white/40"
          >
            Stop Paying For <br />
            <span className="text-zinc-700">Wasted Seats.</span>
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-lg md:text-xl text-zinc-400 max-w-2xl mb-16 leading-relaxed font-medium"
          >
            VendorWise uses AI to scan your SaaS stack, detect inactive licenses, and eliminate duplicate tools automatically. Save up to 30% on software spend this year.
          </motion.p>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-6 mb-32"
          >
            <Button onClick={onGetStarted} size="lg" className="h-16 px-10 text-sm font-bold uppercase tracking-widest bg-indigo-600 hover:bg-indigo-700 text-white rounded-full shadow-2xl shadow-indigo-600/30 border-none transition-all hover:scale-105 active:scale-95">
              Start Scanning Free <ArrowRight className="ml-3 w-4 h-4" />
            </Button>
            <Button size="lg" variant="outline" className="h-16 px-10 text-sm font-bold uppercase tracking-widest border-zinc-800 bg-zinc-900/50 hover:bg-zinc-800 text-zinc-300 rounded-full transition-all">
              Watch Demo
            </Button>
          </motion.div>

          {/* Floating UI Elements Simulation */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.5, duration: 1.2, ease: "easeOut" }}
            className="relative w-full max-w-5xl"
          >
            <div className="absolute -top-20 -left-20 w-96 h-96 bg-indigo-600/10 rounded-full blur-[120px] animate-pulse" />
            <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-emerald-500/5 rounded-full blur-[100px] delay-1000 animate-pulse" />
            
            <div className="bg-zinc-900/50 backdrop-blur-sm rounded-[2rem] overflow-hidden border border-zinc-800 shadow-2xl relative p-4">
              <div className="bg-zinc-950 rounded-[1.5rem] overflow-hidden border border-zinc-800">
                <img 
                  src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=2070" 
                  alt="Dashboard Preview" 
                  className="w-full opacity-30 grayscale group-hover:grayscale-0 transition-all duration-700 h-[600px] object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/20 to-transparent" />
                
                {/* Overlay Stat Cards */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full px-16 grid grid-cols-1 md:grid-cols-3 gap-8">
                  <FloatingCard title="Monthly Spend" val="$42,850" change="+2.4%" icon={DollarSign} delay={0.6} />
                  <FloatingCard title="Annual Waste" val="$142,400" change="-18%" icon={TrendingDown} variant="danger" delay={0.7} />
                  <FloatingCard title="Optimization" val="94%" change="Excellent" icon={ShieldCheck} variant="success" delay={0.8} />
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-24 border-y border-zinc-900 bg-zinc-900/20 overflow-hidden">
        <div className="flex whitespace-nowrap gap-16 text-xl font-bold text-zinc-700 uppercase tracking-[0.3em] px-4 opacity-50">
          {["Linear", "Stripe", "Notion", "Ramp", "Rippling", "Figma", "OpenAI"].map((name) => (
            <div key={name} className="flex items-center gap-6">
              <Zap className="w-5 h-5 text-zinc-800 fill-zinc-800" />
              {name}
            </div>
          ))}
          {/* Duplicate for infinite effect if we had a scroller, but just keeping it static for now */}
          {["Linear", "Stripe", "Notion", "Ramp", "Rippling", "Figma", "OpenAI"].map((name) => (
            <div key={`${name}-2`} className="flex items-center gap-6">
              <Zap className="w-5 h-5 text-zinc-800 fill-zinc-800" />
              {name}
            </div>
          ))}
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-40 px-8 max-w-7xl mx-auto">
        <div className="text-center mb-32 space-y-4">
          <Badge variant="outline" className="border-indigo-500/30 text-indigo-400 font-bold uppercase tracking-widest text-[10px] px-3 py-1">Powerful Features</Badge>
          <h2 className="text-5xl md:text-7xl font-bold tracking-tighter">Everything you need to <br /> <span className="text-zinc-700">tame software sprawl.</span></h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          <FeatureCard 
            icon={Bot} 
            title="AI Expense Scanner" 
            desc="Drag and drop invoices. Our AI extracts vendors, costs, and renewal dates in seconds with 99.9% accuracy."
          />
          <FeatureCard 
            icon={BarChart3} 
            title="Usage Detection" 
            desc="Connect to your HRIS or Identity Provider to see exactly who is (and isn't) using their paid licenses."
          />
          <FeatureCard 
            icon={ShieldCheck} 
            title="Contract Monitoring" 
            desc="Automated alerts 30, 60, and 90 days before a renewal. Never get caught by a surprise price hike again."
          />
          <FeatureCard 
            icon={Layers} 
            title="Overlap Analysis" 
            desc="Detect tools with similar functionality. Stop paying for Slack, Discord, and Teams simultaneously."
          />
          <FeatureCard 
            icon={MousePointer2} 
            title="One-Click Optimization" 
            desc="Cancel subscriptions or downgrade plans directly from our dashboard via intelligent action flows."
          />
          <FeatureCard 
            icon={TrendingDown} 
            title="Real-time Waste Tracking" 
            desc="Watch your overhead vanish. Track actual savings realized across each department month-over-month."
          />
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-40 px-8">
        <div className="max-w-5xl mx-auto bg-indigo-600 rounded-[4rem] p-16 md:p-32 text-center relative overflow-hidden group shadow-3xl shadow-indigo-600/20">
          <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.05)_1px,transparent_1px)] bg-[size:40px_40px] opacity-20" />
          <h2 className="text-5xl md:text-7xl font-bold mb-10 relative z-10 tracking-tighter text-white">Stop the leak today.</h2>
          <p className="text-xl text-white/70 mb-16 max-w-xl mx-auto relative z-10 font-medium">
            Join hundreds of companies that have collectively saved over $40M in wasted SaaS spending.
          </p>
          <Button onClick={onGetStarted} size="lg" className="h-20 px-16 text-sm font-bold uppercase tracking-widest bg-white text-indigo-600 hover:bg-zinc-100 rounded-full relative z-10 shadow-2xl border-none transition-all hover:scale-105 active:scale-95">
            Start Free Audit Now
          </Button>
          
          <div className="absolute -top-20 -right-20 w-96 h-96 bg-white/20 rounded-full blur-[120px] group-hover:scale-110 transition-transform duration-1000" />
          <div className="absolute -bottom-20 -left-20 w-96 h-96 bg-black/20 rounded-full blur-[120px] group-hover:scale-110 transition-transform duration-1000" />
        </div>
      </section>

      {/* Footer */}
      <footer className="py-32 px-8 border-t border-zinc-900 text-zinc-500 font-medium">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-12">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-indigo-600" />
            <span className="font-bold text-lg tracking-tight uppercase text-white">VendorWise AI</span>
          </div>
          <div className="flex gap-12 text-[10px] font-bold uppercase tracking-widest">
            <a href="#" className="hover:text-white transition-colors">Twitter</a>
            <a href="#" className="hover:text-white transition-colors">LinkedIn</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
          </div>
          <p className="text-[10px] font-bold uppercase tracking-widest opacity-50">© 2026 VendorWise AI. Built for scale.</p>
        </div>
      </footer>
    </div>
  );
}

function FloatingCard({ title, val, change, icon: Icon, variant = 'primary', delay = 0 }) {
  const colors = {
    primary: 'text-indigo-400',
    success: 'text-emerald-400',
    danger: 'text-rose-500',
  };

  const glowColors = {
    primary: 'glow-indigo',
    success: 'glow-emerald',
    danger: 'glow-rose',
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.8, ease: "easeOut" }}
      className={cn("bg-zinc-900 border border-zinc-800 rounded-3xl p-8 animate-float", glowColors[variant])}
      style={{ animationDelay: `${delay}s` }}
    >
      <div className="flex items-center justify-between mb-6">
        <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-[0.2em]">{title}</span>
        <div className={cn("p-2 rounded-xl bg-zinc-800/50", colors[variant])}>
          <Icon className="w-4 h-4" />
        </div>
      </div>
      <div className="text-4xl font-bold mb-3 tracking-tighter text-white">{val}</div>
      <div className={cn("text-xs font-bold font-mono", colors[variant])}>{change}</div>
    </motion.div>
  );
}

function FeatureCard({ icon: Icon, title, desc }) {
  return (
    <div className="group p-10 rounded-[2.5rem] bg-zinc-900/50 border border-zinc-800 hover:bg-zinc-900 transition-all duration-500 hover:-translate-y-2">
      <div className="w-16 h-16 bg-zinc-800 rounded-3xl flex items-center justify-center mb-8 border border-zinc-700 group-hover:bg-indigo-600/10 group-hover:border-indigo-600/40 transition-all duration-500 shadow-inner">
        <Icon className="w-6 h-6 text-zinc-500 group-hover:text-indigo-400 transition-colors duration-500" />
      </div>
      <h3 className="text-2xl font-bold mb-4 tracking-tight text-white">{title}</h3>
      <p className="text-zinc-500 text-sm leading-relaxed font-medium">{desc}</p>
    </div>
  );
}

function Sparkles(props: any) {
  return (
    <svg 
      {...props} 
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    >
      <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/>
      <path d="M5 3v4"/><path d="M19 17v4"/><path d="M3 5h4"/><path d="M17 19h4"/>
    </svg>
  );
}

