import { create } from 'zustand';
import { Vendor, Recommendation, Invoice, DashboardStats } from './types';
import { MOCK_VENDORS, MOCK_RECOMMENDATIONS, MOCK_INVOICES, MOCK_STATS } from './mockData';

interface AppState {
  vendors: Vendor[];
  recommendations: Recommendation[];
  invoices: Invoice[];
  stats: DashboardStats;
  isDemoMode: boolean;
  isLoading: boolean;
  
  // Actions
  setDemoMode: (enabled: boolean) => void;
  addInvoice: (invoice: Invoice) => void;
  applyRecommendation: (id: string) => void;
  updateStats: () => void;
}

export const useAppStore = create<AppState>((set, get) => ({
  vendors: MOCK_VENDORS,
  recommendations: MOCK_RECOMMENDATIONS,
  invoices: MOCK_INVOICES,
  stats: MOCK_STATS,
  isDemoMode: true,
  isLoading: false,

  setDemoMode: (enabled: boolean) => {
    if (enabled) {
      set({ 
        vendors: MOCK_VENDORS, 
        recommendations: MOCK_RECOMMENDATIONS, 
        invoices: MOCK_INVOICES,
        isDemoMode: true 
      });
    } else {
      set({ vendors: [], recommendations: [], invoices: [], isDemoMode: false });
    }
  },

  addInvoice: (invoice: Invoice) => {
    set((state) => ({ invoices: [invoice, ...state.invoices] }));
  },

  applyRecommendation: (id: string) => {
    set((state) => ({
      recommendations: state.recommendations.map((r) => 
        r.id === id ? { ...r, status: 'applied' } : r
      )
    }));
  },

  updateStats: () => {
    // Logic to recalculate stats based on current vendors/recommendations
    const { vendors } = get();
    const totalMonthly = vendors.reduce((sum, v) => sum + v.monthlySpend, 0);
    const waste = vendors.filter(v => v.status !== 'active').reduce((sum, v) => sum + v.monthlySpend, 0);
    
    set((state) => ({
      stats: {
        ...state.stats,
        totalMonthlySpend: totalMonthly,
        estimatedWaste: waste,
      }
    }));
  }
}));
